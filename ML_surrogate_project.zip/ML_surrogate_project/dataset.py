import os
print(os.listdir())
import numpy as np
import pandas as pd
import json
from scipy.optimize import brentq

# Constants 
gamma = 1.4
Dt    = 7.7  # mm

def get_NPR_design(De):
    AeAt = (De/Dt)**2
    def f(M):
        term = (2/(gamma+1))*(1+(gamma-1)/2*M**2)
        exp  = (gamma+1)/(2*(gamma-1))
        return (1/M)*term**exp - AeAt
    M = brentq(f, 1.01, 10)
    return (1+(gamma-1)/2*M**2)**(gamma/(gamma-1))

#STEP 1: LOAD ALL 26 FILES
# file naming: De10_NPRlow_centerline.xy
# Fluent .xy file has 3 header lines then:
# x(m)Mach

cases = []
for De in range(10, 23):          # 10 to 22mm
    NPR_des  = get_NPR_design(De)
    NPR_low  = 2.0
    NPR_high = round(0.95 * NPR_des, 2)
    cases.append((De, NPR_low,  'low',  NPR_des))
    cases.append((De, NPR_high, 'high', NPR_des))

all_data = []
for De, NPR, cond, NPR_des in cases:
    fname = f"De{De}_NPR{cond}_centerline"
    
    try:
        df = pd.read_csv(
            fname,
            skiprows=4,          # skip Fluent header
            sep=r'\s+',
            header=None,
            names=['x_m', 'Mach']
        )
        df['x_m'] = pd.to_numeric(df['x_m'], errors='coerce')
        df['Mach'] = pd.to_numeric(df['Mach'], errors='coerce')
        df = df.sort_values('x_m')
        df = df.reset_index(drop=True)
        df = df.dropna(subset=['x_m','Mach'])
        
        # Convert x to mm
        df['x_mm']     = df['x_m'] * 1000
        
        # Add case information
        df['De']        = De
        df['NPR']       = NPR
        df['condition'] = cond
        df['AeAt']      = (De / Dt)**2
        df['NPR_des']   = NPR_des
        df['NPR_ratio'] = NPR / NPR_des
        
        all_data.append(df)
        print(f"Loaded: De={De}mm, NPR={NPR} ({cond}) "
              f"→ {len(df)} points")
        
    except FileNotFoundError:
        print(f"MISSING: {fname}")

dataset = pd.concat(all_data, ignore_index=True)
print(f"\nTotal rows: {len(dataset)}")
print(f"Total cases: {dataset.groupby(['De','condition']).ngroups}")

test_De  = [14, 16, 20]
val_De   = [12, 18]
train_De = [De for De in range(10, 23)
            if De not in test_De
            and De not in val_De]

print(f"Train De: {train_De}")
print(f"Val De:   {val_De}")
print(f"Test De:  {test_De}")

train_df = dataset[dataset['De'].isin(train_De)].copy()
val_df   = dataset[dataset['De'].isin(val_De)].copy()
test_df  = dataset[dataset['De'].isin(test_De)].copy()

print(f"\nTrain: {len(train_df)} rows")
print(f"Val:   {len(val_df)} rows")
print(f"Test:  {len(test_df)} rows")

# Compute min/max from TRAIN SET ONLY
x_min      = train_df['x_mm'].min()
x_max      = train_df['x_mm'].max()
AeAt_min   = train_df['AeAt'].min()
AeAt_max   = train_df['AeAt'].max()
NPRr_min   = train_df['NPR_ratio'].min()
NPRr_max   = train_df['NPR_ratio'].max()
Mach_min   = train_df['Mach'].min()
Mach_max   = train_df['Mach'].max()

print("Normalization constants from train:")
print(f"x:         [{x_min:.4f}, {x_max:.4f}] mm")
print(f"AeAt:      [{AeAt_min:.4f}, {AeAt_max:.4f}]")
print(f"NPR_ratio: [{NPRr_min:.4f}, {NPRr_max:.4f}]")
print(f"Mach:      [{Mach_min:.4f}, {Mach_max:.4f}]")

# Save constants needed for denormalization later
norm = {
    'x_min':    float(x_min),
    'x_max':    float(x_max),
    'AeAt_min': float(AeAt_min),
    'AeAt_max': float(AeAt_max),
    'NPRr_min': float(NPRr_min),
    'NPRr_max': float(NPRr_max),
    'Mach_min': float(Mach_min),
    'Mach_max': float(Mach_max)
}
json.dump(norm, open('norm_constants.json', 'w'), indent=2)
print("\nSaved: norm_constants.json")

# Apply to ALL splits using SAME constants
eps = 1e-8   # prevents division by zero

def normalize(df, norm):
    df = df.copy()
    df['x_norm']    = (df['x_mm']     - norm['x_min'])   / \
                      (norm['x_max']   - norm['x_min']   + eps)
    df['AeAt_norm'] = (df['AeAt']     - norm['AeAt_min'])/ \
                      (norm['AeAt_max']- norm['AeAt_min']+ eps)
    df['NPRr_norm'] = (df['NPR_ratio'] - norm['NPRr_min'])/ \
                      (norm['NPRr_max']- norm['NPRr_min']+ eps)
    df['Mach_norm'] = (df['Mach']     - norm['Mach_min'])/ \
                      (norm['Mach_max']- norm['Mach_min']+ eps)
    return df

train_df = normalize(train_df, norm)
val_df   = normalize(val_df,   norm)   # same constants
test_df  = normalize(test_df,  norm)   # same constants

# Quick check train should be [0,1]
print(f"\nTrain x_norm range:    "
      f"[{train_df['x_norm'].min():.3f}, "
      f"{train_df['x_norm'].max():.3f}]")
print(f"Train AeAt_norm range: "
      f"[{train_df['AeAt_norm'].min():.3f}, "
      f"{train_df['AeAt_norm'].max():.3f}]")
print(f"Train Mach_norm range: "
      f"[{train_df['Mach_norm'].min():.3f}, "
      f"{train_df['Mach_norm'].max():.3f}]")

# Val/Test may slightly exceed [0,1] that is OK
print(f"Test Mach_norm range:  "
      f"[{test_df['Mach_norm'].min():.3f}, "
      f"{test_df['Mach_norm'].max():.3f}]")

# STEP 4 — Compute Shock-Aware Weights
def compute_weights(df, beta=3.0, 
                    clip_percentile=95,
                    throat_x_m=0.0382):
    weights = []
    
    for (De, cond), case in df.groupby(
            ['De', 'condition']):
        
        case  = case.sort_values('x_mm')
        mach  = case['Mach'].values
        x     = case['x_m'].values
        
        # Compute gradient everywhere
        grad  = np.abs(np.gradient(mach, x))
        
        # Zero out gradient before throat exit
        # Throat exit = end of diverging section
        # = converging(25mm) + diverging(13.2mm) = 38.2mm
        throat_mask        = x < throat_x_m
        grad[throat_mask]  = 0.0
        
        # Clip at 95th percentile
        clip_val     = np.percentile(
                           grad[~throat_mask], 
                           clip_percentile)
        grad_clipped = np.clip(grad, 0, clip_val)
        
        # Normalize to [0,1]
        g_max     = grad_clipped.max()
        g_min     = grad_clipped.min()
        grad_norm = (grad_clipped - g_min) / \
                    (g_max - g_min + 1e-8)
        
        # Final weight
        w = 1.0 + beta * grad_norm
        
        weights.append(
            pd.Series(w, index=case.index))
    
    return pd.concat(weights)

# Recompute with throat mask
train_df['weight'] = compute_weights(
    train_df, 
    beta=3.0,
    clip_percentile=95,
    throat_x_m=0.0382   # converging(0.025) + diverging(0.0132)
)

# Recompute with throat mask
train_df['weight'] = compute_weights(
    train_df, 
    beta=3.0,
    clip_percentile=95,
    throat_x_m=0.0382   # converging(0.025) + diverging(0.0132)
)

# # Apply to train only
# train_df['weight'] = compute_weights(
#     train_df, beta=3.0, clip_percentile=95)

print(f"Weight range: "
      f"[{train_df['weight'].min():.3f}, "
      f"{train_df['weight'].max():.3f}]")
print("Expected: [1.0, 4.0]")

# for saving file train_df.to_csv("train_dataset.csv", index=False)
train_df.to_csv("train_dataset.csv", index=False)
val_df.to_csv("val_dataset.csv", index=False)
test_df.to_csv("test_dataset.csv", index=False)

print("Datasets saved.")

# STEP 5 Verify Everything Before Training

import matplotlib.pyplot as plt

# Check one case weights
sample = train_df[
    (train_df['De']==10) &
    (train_df['condition']=='low')
].sort_values('x_m')

fig, axes = plt.subplots(1, 2, figsize=(14, 4))

axes[0].plot(sample['x_m'], sample['Mach'], 'b-')
axes[0].set_xlabel('x [m]')
axes[0].set_ylabel('Mach')
axes[0].set_title('De=10mm NPR_low — Mach Profile')
axes[0].grid(True)

axes[1].plot(sample['x_m'], sample['weight'], 'r-')
axes[1].set_xlabel('x [m]')
axes[1].set_ylabel('Sample Weight')
axes[1].set_title('De=10mm NPR_low — Weights')
axes[1].grid(True)

plt.tight_layout()
plt.savefig('weight_check.png', dpi=150)
plt.show()

# Shock region should have highest weights
print("\nTop 5 weight values:")
print(sample[['x_m','Mach','weight']]\
      .nlargest(5, 'weight')[['x_m','weight']])

print(
    sample[['x_m','Mach','weight']]
    .nlargest(20,'weight')
)
print(sample[['x_m','Mach','weight']]
      .nlargest(15,'weight'))



 
