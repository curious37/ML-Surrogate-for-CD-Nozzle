import pandas as pd
import numpy as np

import torch
import torch.nn as nn
device = torch.device(
    "cuda" if torch.cuda.is_available()
    else "cpu"
)

print("Using device:", device)

from torch.utils.data import (
    TensorDataset,
    DataLoader
)

train_df = pd.read_csv("train_dataset.csv")
val_df   = pd.read_csv("val_dataset.csv")
test_df  = pd.read_csv("test_dataset.csv")

print("Loaded datasets")
torch.manual_seed(42)
np.random.seed(42)

X_train = train_df[
    ['x_norm',
     'AeAt_norm',
     'NPRr_norm']
].values

y_train = train_df[
    'Mach_norm'
].values

w_train = train_df[
    'weight'
].values

X_val = val_df[
    ['x_norm',
     'AeAt_norm',
     'NPRr_norm']
].values

y_val = val_df[
    'Mach_norm'
].values

X_test = test_df[
    ['x_norm',
     'AeAt_norm',
     'NPRr_norm']
].values

y_test = test_df[
    'Mach_norm'
].values
#Step 4: Convert to Tensors
X_tr = torch.tensor(
    X_train,
    dtype=torch.float32
)

y_tr = torch.tensor(
    y_train,
    dtype=torch.float32
).unsqueeze(1)

w_tr = torch.tensor(
    w_train,
    dtype=torch.float32
).unsqueeze(1)

X_vl = torch.tensor(
    X_val,
    dtype=torch.float32
)

y_vl = torch.tensor(
    y_val,
    dtype=torch.float32
).unsqueeze(1)

X_te = torch.tensor(
    X_test,
    dtype=torch.float32
)

y_te = torch.tensor(
    y_test,
    dtype=torch.float32
).unsqueeze(1)
#Step 5: Create Datasets and DataLoaders
train_loader = DataLoader(
    TensorDataset(
        X_tr,
        y_tr,
        w_tr
    ),
    batch_size=64,
    shuffle=True
)

val_loader = DataLoader(
    TensorDataset(
        X_vl,
        y_vl
    ),
    batch_size=64,
    shuffle=False
)

print("Train batches:",
      len(train_loader))

class ResidualMLP(nn.Module):

    def __init__(self):
        super().__init__()

        self.fc1 = nn.Linear(3, 64)
        self.fc2 = nn.Linear(64, 64)

        # Skip projection
        self.skip = nn.Linear(3, 64)

        self.fc3 = nn.Linear(64, 32)
        self.fc4 = nn.Linear(32, 1)

        self.relu = nn.ReLU()

        # Xavier Initialization
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):

        # Main branch
        h = self.relu(self.fc1(x))
        h = self.relu(self.fc2(h))

        # Skip connection
        s = self.skip(x)

        # Residual addition
        h = self.relu(h + s)

        h = self.relu(self.fc3(h))

        out = self.fc4(h)

        return out
    
    #Create Model
model = ResidualMLP().to(device)

print(model)

X_batch, y_batch, w_batch = next(
    iter(train_loader)
)

X_batch = X_batch.to(device)

pred = model(X_batch)

print(pred.shape)

criterion = nn.MSELoss()

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=1e-4,
    weight_decay=1e-5
)
#validation function
def evaluate(model, val_loader):

    model.eval()

    total_loss = 0.0

    with torch.no_grad():

        for X, y in val_loader:

            X = X.to(device)
            y = y.to(device)

            pred = model(X)

            loss = criterion(pred, y)

            total_loss += loss.item()

    return total_loss / len(val_loader)
#Training Loop
epochs = 200

for epoch in range(epochs):

    model.train()

    train_loss = 0.0

    for X, y, w in train_loader:

        X = X.to(device)
        y = y.to(device)

        optimizer.zero_grad()

        pred = model(X)

        loss = criterion(pred, y)

        loss.backward()

        torch.nn.utils.clip_grad_norm_(
        model.parameters(),
        1.0
       )

        optimizer.step()

        

        train_loss += loss.item()

    train_loss /= len(train_loader)

    val_loss = evaluate(
        model,
        val_loader
    )

    print(
        f"Epoch {epoch+1:3d} | "
        f"Train={train_loss:.6f} | "
        f"Val={val_loss:.6f}"
    )
    

    #sklearn.metrics.mean_squared_error(
    from sklearn.metrics import (
    r2_score,
    mean_squared_error
)
    model.eval()

with torch.no_grad():

    pred_test = model(
        X_te.to(device)
    )

pred_test = pred_test.cpu().numpy()
model.eval()

with torch.no_grad():

    pred_test = model(
        X_te.to(device)
    )

pred_test = pred_test.cpu().numpy()
r2 = r2_score(
    y_test,
    pred_test
)

rmse = np.sqrt(
    mean_squared_error(
        y_test,
        pred_test
    )
)

print("R2 =", r2)
print("RMSE =", rmse)

torch.save(
    model.state_dict(),
    "fcnn_baseline.pth"
)
fcnn_r2   = r2
fcnn_rmse = rmse

#visual comparison
# 
case = test_df[
    (test_df['De'] == 14) &
    (test_df['condition'] == 'high')
].copy()

print(case.shape)

X_case = case[
    ['x_norm',
     'AeAt_norm',
     'NPRr_norm']
].values

X_case = torch.tensor(
    X_case,
    dtype=torch.float32
).to(device)

model.eval()

with torch.no_grad():

    pred = model(X_case)

pred = pred.cpu().numpy().flatten()

import json

norm = json.load(
    open("norm_constants.json")
)

mach_pred = (
    pred *
    (norm['Mach_max'] -
     norm['Mach_min'])
    +
    norm['Mach_min']
)

mach_cfd = case['Mach'].values
x = case['x_mm'].values

import matplotlib.pyplot as plt

plt.figure(figsize=(10,5))

plt.plot(
    x,
    mach_cfd,
    'k-',
    linewidth=2,
    label='CFD'
)

plt.plot(
    x,
    mach_pred,
    'r--',
    linewidth=2,
    label='train_residual'
)

plt.xlabel("x [mm]")
plt.ylabel("Mach Number")

plt.title(
    "De=14 mm, NPR_high\nCFD vs train_residual"
)

plt.legend()

plt.grid(True)

plt.savefig(
    "De14_high_comparison.png",
    dpi=300
)

plt.show()

